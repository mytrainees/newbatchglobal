package Abstraction;

public interface CarInterface {
	// only abstract methods present in Interface .. thats why we achive 100% abstraction 
	
	public void start();  // no body  -- empty suitcases provided, they can keep whatever the belongings they want to keep 
	public void stop();
	public void fuel();
	
// interface can have only final and static variables
	
}
