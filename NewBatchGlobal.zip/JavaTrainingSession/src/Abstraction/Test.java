package Abstraction;

public class Test {

	public static void main(String[] args) {
      HDFCbank hb = new HDFCbank();
     
      hb.credit();
      hb.debit();
      hb.loan();
	
	}

}
