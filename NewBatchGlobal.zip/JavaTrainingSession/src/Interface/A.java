package Interface;

public interface A {

void method1();
void method2();
}
