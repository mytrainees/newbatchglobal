package Interface;

class B implements A{
	public void method1() {
		System.out.println(" inhertied method  from interface A");
	}
	public void method2() {
		System.out.println(" this is also inhertied method from interface ");
	}
	
	void show() {
		System.out.println(" this is my normal show method");
	}
	
	public static void main (String []args) {
		B obj = new B();
		obj.method1();
		obj.method2();
		obj.show();
		
	}
}
