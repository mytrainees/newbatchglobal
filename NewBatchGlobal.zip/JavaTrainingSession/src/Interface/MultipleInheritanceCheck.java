package Interface;



	public interface Continent{    // interface 1
		void ContinentName();
		
	}
	
	
	public interface Country{       // interface 2
		void CountryName();
	}
	
	
	public interface City{         // interface 3
		void CityName();
	}
	
	
	public class MultipleInheritanceCheck implements Continent,Country,City {   // multiple inheritance by interface  
	
		public void ContinentName() {
			System.out.println(" Europe");
		}
	
		public void  CountryName() {
			System.out.println(" Denmark");
		}
		public void  CityName() {
			System.out.println(" Copenhagen");
		}
		
	public static void main(String[] args) {
		
		MultipleInheritanceCheck obj= new MultipleInheritanceCheck();
		obj.ContinentName();
		obj.CountryName();
		obj.CityName();

	}

}
