package JavaBasics;


class A{
	void method(){
		System.out.println(" override annotation checking ");
	}
	
}

public class AnnotationDemo {
	
	
	void methed() {
		System.out.println(" abbiatuiba jfa k");
	}

	public static void main(String[] args) {
		AnnotationDemo d = new AnnotationDemo();
		d.methed();

	}

}
