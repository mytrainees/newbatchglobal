package JavaBasics;


public class A {
	public void methodtoDemoAnnotation() {
		System.out.println( " This method is going to override ");
	}
}

public class AnnotationExample  extends A  {
	public void methodtodemoAnnotation () {
		System.out.println( " Check it................... ");
	}

	public static void main(String[] args) {
		
		AnnotationExample obj = new AnnotationExample();
		obj.methodtoDemoAnnotation();

	}

}
