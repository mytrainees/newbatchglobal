package JavaBasics;

public class DataTypes {
// this is how you write comments ,,,, comments good for future reference
	// main method is starting/execution point of the program
	public static void main(String[] args) {
		

		
		int a =20;     // datatype variable name = value;
		
		
		byte b =3; 
		long c= 20;
			 
		short d = 200; 
		System.out.println(" this is my integer value     :"   +d);
		
		System.out.println(a+b);
		
		float e =12.33f;
		double f = 23343434.345676;
		char g = 'a';
		
		boolean h = true;
		
		
		
		
		
		int i =10;
		int k =-1;
		System.out.println("this is my first class"
				+ "");
		
		double l = 12.33;  // i am commenting to rememmber my code because i am not a computer 
		double l1= 100;
	
		
		char z = 'a';
		char c1 = '1';
		
		boolean x = true;
		boolean b1= false;
	
	System.out.println(l+l1);
			
			

	}

}
