package JavaBasics;

public class IfElseConcept {

	public static void main(String[] args) {
        int a = 100;
        int b = 20;
        
        if (b>a) { 
        	System.out.println(" b is greater than a ");
        }
        else {
        	System.out.println(" a is greater than b");
        }
	//comparision operators :  <>  <=  >=   ==  !=
        // = is assignment operator,  == is equal operator 
        
        int c =20;
        int d = 10;
        if (c==d) {
        	System.out.println(" c is equal to d  ");
        }
        else {
        	System.out.println("c is not equal to d");
        }
	
	
	
	
	}
	
	
	

}
