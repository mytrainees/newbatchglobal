package JavaBasics;

public class OpeartorsInJava {

	public static void main(String[] args) {
// arithmetic operators
		int a =20;
		int b =30;
		System.out.println(" This is addition operator     :"   +(a+b));
		System.out.println(" This is multiplication  operator     "  +(a*b));
		System.out.println(" This is subtraction operator    " +(b-a));
		System.out.println(" This is division operator"     +(b/a));
		System.out.println(" This is modulus operator   "   +(a%b) );
	}

}
