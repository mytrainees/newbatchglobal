package JavaBasics;

public class Sample {

	public static void main(String[] xyz) {
int i=10;
System.out.println(" fakjlk jf " );
	}

}
