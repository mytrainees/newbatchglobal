package JavaBasics;

public class Variables {

	static int c =30;    // static variable 
	int a =10;          // This variable for some logic   ..... instance variable 
	
	public static void main(String[] args) {
     System.out.println(" My name is Sravya and this is my first java program");
      
     int b =20;                           // local variable 
                                         //  you can write comments 
	
	                                    // fw jfdslk; fjasl;dfj lakj flaksj 
	
	}

}
