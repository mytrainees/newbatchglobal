package Multithread;

public class Mythread extends Thread {
	
	public void run() {
		System.out.println( " My thread is in running state");
	}
}