
public class ThrowsException {

	public static void main(String[] args) throws InterruptedException  {
		
			
		Thread.sleep(1000);
		System.out.println(" let sleep");
	}

}
