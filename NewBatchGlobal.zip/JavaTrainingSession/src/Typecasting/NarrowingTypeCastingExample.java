package Typecasting;

public class NarrowingTypeCastingExample  
{  
public static void main(String args[])  
{  
double d = 166.66;    // if you want convert double to int,,, you have convert to long first

                                                //converting double data type into long data type  
long l = (long)d;  

int i = (int)l; 

                                                         //converting long data type into int data type  
 
System.out.println("Before conversion: "+d);  
 
System.out.println("After conversion into long type: "+l);  

System.out.println("After conversion into int type: "+i);  
}  
}  
