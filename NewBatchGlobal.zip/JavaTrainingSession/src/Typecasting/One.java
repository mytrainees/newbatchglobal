package Typecasting;

public class One 
{ 
  void m1() 
  { 
     System.out.println("m1 method in class One"); 
   } 
 } 