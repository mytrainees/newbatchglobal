package Typecasting;

public class Two extends One 
{ 
  void m2() 
  { 
     System.out.println("m2 method in class Two"); 
   } 
} 