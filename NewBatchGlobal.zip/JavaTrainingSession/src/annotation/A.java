package annotation;

class A {
	public void methodtoDemoAnnotation() {
		System.out.println( " This is parent logic .... This method is going to override ");
	}
}