package assignments;



public class Average {
	
	public static void main(String[]args) {
	double avg=0;
	
	int x [] = new int[5];
	
	x[0]= 20;
	x[1]=20;
	x[2]=20;
	x[3]= 20;
	x[4]= 20;
	
	for(int i=0;i<5; i++)
		avg=avg+x[i];          //  a[0]  = 75....   a[2]  =  75+80+35+99+90= total marks stores in avg variable
	
	System.out.println(" The average of five subjects is :   " +avg/5 );
	
}}
