package assignments;

public class Person {

int age=50;
}
