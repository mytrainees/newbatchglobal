package encapsulation;

class EncapTest 
{ 
 public static void main(String[] arg) 
 { 
   Student obj = new Student();
   obj.setName(" my name is encapsulated variable ");
   obj.getName ();
   
   String studentName= obj.getName();
   System.out.println(studentName);
   
   
   
                                                   // compilation error. because  name is private. 
             // to solve this error call the getter, getName(), and the setter setName() 
                                      // to read and update the value of variable. 
 } 
}