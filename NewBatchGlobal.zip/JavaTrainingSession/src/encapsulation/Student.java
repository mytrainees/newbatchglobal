package encapsulation;

public class Student 
{ 
  private String name;   
      //getName()   getName()

public String getName() {         // get and followed name of the variable, starting letter should be capital
	return name;
}


public void setName(String name) {
	this.name = name;
} 
 
  
}