package multipleinheritance;

public interface CanadaBank {
	
	public void insurance();
	

}
