package multipleinheritance;

public class Test {

	public static void main(String[] args) {
       HDFCbank h = new HDFCbank();
       h.deposit();
       h.withdraw();
       h.moneytransfer();
       h.myownmethod1();
       h.myownmetho2();
       System.out.println("___________________________________");
       h.insurance();
	}

}
