package multipleinheritance;

public interface USbank {
	public void deposit();
	public void withdraw();
	public void moneytransfer();
	

}
