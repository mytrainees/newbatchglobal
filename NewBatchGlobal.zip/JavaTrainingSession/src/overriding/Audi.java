package overriding;

public class Audi extends Car {  // HAS a relation 
	
	
	public void start() {
		System.out.println(" start method from child class AUDI ");
	}
	public void stop() {
		System.out.println(" stop method from child class AUDI ");
	}
 public void mybrand() {
	 System.out.println(" my own method ");
 }

}
