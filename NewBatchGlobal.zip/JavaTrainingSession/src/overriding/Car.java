package overriding;

public class Car extends Vehicle {
	
	public void start() {
		System.out.println(" This is start method from car class");
	}
public void stop( ) { 
	System.out.println(  "  stop method from car class");
}
    public void fuel() {
    	System.out.println(" fuel method from car class");
    }
}
